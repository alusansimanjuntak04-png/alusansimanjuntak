"# alusansimanjuntak" 
