int speed; //Non Static

Static int jumlahMAhasiswa; // Static Fields

void hitung() {
    int count = 0; // local variabel
}

void setNama(String nama) {
    this.nama = nama;
}

int umur = 20;
double gaji = 3500000.50;
boolean lulus = true;
String nama = "Budi"; // PEnamaan variabel


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg41425040_alusan;

/**
 *
 * @author user
 */
public class JenisVariabel {
    
}
