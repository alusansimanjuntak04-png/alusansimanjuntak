package pkg41425040_alusan;

public class TebakOutput {
    public static void main(String[] args) {
        int nilaiUjian = 80;
            System.out.println("Nilai ujian kamu: " + nilaiUjian);
    }
}