//Implicit
int myInt = 9;
double myDouble = myInt; // otomatis

//Explicit
double myDouble - 9.78:
int myInt = (int) myDouble: // hasil 9, .78 hilang