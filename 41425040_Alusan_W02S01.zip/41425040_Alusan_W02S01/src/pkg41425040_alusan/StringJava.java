String nama = "Budi";
System.out.println(nama.length());
System.out.println(nama. toUpperCase()); // "BUDI"
System.out.println(nama.equals("Budi")); // true
