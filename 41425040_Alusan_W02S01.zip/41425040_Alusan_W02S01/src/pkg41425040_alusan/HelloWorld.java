package pkg41425040_alusan;

public class HelloWorld {

    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}