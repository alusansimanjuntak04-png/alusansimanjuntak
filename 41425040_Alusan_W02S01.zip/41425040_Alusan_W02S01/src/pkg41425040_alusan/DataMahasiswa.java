package pkg41425040_alusan;

public class DataMahasiswa {
    public static void main(String[] args) {
        String nama = "Budi";
        int umur = 19;
        boolean statusAktif = true;
            System.out.println(nama + " berumur " + umur);
    }
}