// buat array 10 elemen
anArray - new int[10];

// isi nilai
anArray[0] - 100;
anArray[1] = 200:

// Shortcut Inisialisasi Array
int[] anArray = {100,200,300,400};

// Akses Elemen Array

System.out.print1n(anArray[0]); // 100
System.out.println(anArray[1]); // 200


//Array Multidimensi
String[][] names = {
{"Mr. ", "Mrs. ", "Ms. "}.
{"Smith", "Jones"}
};

System.out.println(names[0][0] + names[1][0]); // Mr. Smith
System.out.println(names[0][2] + names[1][1]); // Ms. Jones

