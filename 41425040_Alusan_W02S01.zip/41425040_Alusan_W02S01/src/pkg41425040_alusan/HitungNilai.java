package pkg41425040_alusan;

public class HitungNilai{
    public static void main(String[] args) {
        int totalNilai = 85;
        int jumlahMatkul = 2;
        double ratarata = totalNilai + jumlahMatkul;
            System.out.println(ratarata);
    }
}